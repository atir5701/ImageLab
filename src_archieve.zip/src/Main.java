import java.io.IOException;
import java.util.Collections;
import java.util.Scanner;

import Controller.CommandHandler;

public class Main {
  public static void main(String[] args) throws IOException {
    Scanner scn = new Scanner(System.in);
    CommandHandler e = new CommandHandler();
    while(scn.hasNextLine()) {
      String cmd =scn.nextLine();
      e.readCommand(cmd);
    }
  }
}