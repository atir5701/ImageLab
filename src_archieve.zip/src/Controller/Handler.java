package Controller;

import java.io.IOException;

import Model.ImageModel;
import Model.Operations;

/**
 * The interface represents the various
 */

public interface Handler {

  void readCommand(String command) throws IOException;
}
