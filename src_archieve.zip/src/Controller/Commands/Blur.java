package Controller.Commands;

import Model.Operations;

public class Blur extends AbstractCommandExecuter{
  String currentImageName;
  String newImageName;

  public Blur(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length, commandLength);
    this.currentImageName = cmd[1];
    this.newImageName = cmd[2];
  }


  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.blur(this.currentImageName,this.newImageName);
  }

}
