package Controller.Commands;

import Model.Operations;

public class Brighten extends AbstractCommandExecuter {
  private final String currentImageName;
  private final String newImageName;
  private int increment;

  public Brighten(String[] cmd,int commandLength) throws NumberFormatException{
    this.validCommandLength(cmd.length,commandLength);
    this.currentImageName = cmd[2];
    this.newImageName = cmd[3];

    try{
      this.increment = Integer.parseInt(cmd[1]);
    }catch (NumberFormatException e){
      System.out.println("Invalid increment value");
    }
  }

  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.brighten(this.currentImageName, this.newImageName, this.increment);
  }
}
