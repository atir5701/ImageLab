package Controller.Commands;

import Model.ImageOperations;
import Model.Operations;

public class RGBSplit extends AbstractCommandExecuter{
  String currentImageName;
  String redNewImage;
  String greenNewImage;
  String blueNewImage;

  public RGBSplit(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length,commandLength);
    this.currentImageName = cmd[1];
    this.redNewImage = cmd[2];
    this.greenNewImage = cmd[3];
    this.blueNewImage = cmd[4];
  }

  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.splitRGB(this.currentImageName,this.redNewImage,this.greenNewImage,this.blueNewImage);
  }
}
