package Controller.Commands;

import Model.Operations;

public class ColorComponent extends AbstractCommandExecuter{
  String currentImageName;
  String newImageName;
  String handler;
  public ColorComponent(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length, commandLength);
    this.currentImageName = cmd[1];
    this.newImageName = cmd[2];
    this.handler = cmd[0];
  }

  @Override
  public void execute(Operations operations) throws IllegalArgumentException {
    this.imageCheck(operations,this.currentImageName);
    int color;
    switch (handler){
      case "red-component":
        color=0;
        break;
      case "green-component":
        color = 1;
        break;
      case "blue-component":
        color = 2;
        break;
      default:
        throw new IllegalArgumentException("Invalid command provided");
    }
    operations.getColorComponent(this.currentImageName,this.newImageName,color);
  }

}
