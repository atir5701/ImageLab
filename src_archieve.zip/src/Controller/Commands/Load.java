package Controller.Commands;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import javax.imageio.ImageIO;

import Model.Operations;

public class Load extends AbstractCommandExecuter{
  private String filePath;
  private String currentImageName;
  private String extension;

  public Load(String [] cmd,int commandLength) {
    this.validCommandLength(cmd.length,commandLength);
    this.filePath = cmd[1];
    this.extension = this.filePath.substring(this.filePath.lastIndexOf(".") + 1);
    this.currentImageName = cmd[2];
  }

  @Override
  public void execute(Operations operations) throws IllegalArgumentException{
    switch (this.extension){
      case "png":
      case "jpeg":
        this.loadPngJpeg(operations);
        break;
      case "ppm":
        this.loadPPM(operations);
        break;
      default:
        throw new IllegalArgumentException("This extension is not Supported");
    }
  }

  private void loadPngJpeg(Operations operations){
    File file = new File(this.filePath);
    try {
      BufferedImage img = ImageIO.read(file);
      int height = img.getHeight();
      int width = img.getWidth();
      int [][][] arr = new int[height][width][3];
      for(int i=0;i<height;i++){
        for(int j=0;j<width;j++){
          int rgb = img.getRGB(j, i);
          arr[i][j][0] = (rgb>>16) & 0xff;
          arr[i][j][1] = (rgb>>8) & 0xff;
          arr[i][j][2] = (rgb) & 0xff;
        }
      }
      operations.loadImages(arr,this.currentImageName);
    } catch (IOException e) {
      System.out.println("File Not Found");
    }
  }

  private void loadPPM(Operations operations){
    Scanner sc;
    try {
      sc = new Scanner(new FileInputStream(this.filePath));
    }
    catch (FileNotFoundException e) {
      System.out.println("File not found!");
      return;
    }
    StringBuilder builder = new StringBuilder();
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0)!='#') {
        builder.append(s+System.lineSeparator());
      }
    }
    sc = new Scanner(builder.toString());
    String token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
      return;
    }
    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();
    int [][][] arr = new int[height][width][3];
    for (int i=0;i<height;i++) {
      for (int j=0;j<width;j++) {
        arr[i][j][0] = sc.nextInt();
        arr[i][j][1] = sc.nextInt();
        arr[i][j][2] = sc.nextInt();
      }
    }
    operations.loadImages(arr,this.currentImageName);
  }
}
