package Controller.Commands;

import Model.Operations;

public class VerticalFlip extends AbstractCommandExecuter{
  String currentImageName;
  String newImageName;

  public VerticalFlip(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length,commandLength);
    this.currentImageName = cmd[1];
    this.newImageName = cmd[2];
  }
  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.verticalFlip(this.currentImageName,this.newImageName);
  }
}
