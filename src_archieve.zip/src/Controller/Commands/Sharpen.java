package Controller.Commands;

import Model.Operations;

public class Sharpen extends AbstractCommandExecuter{
  String currentImageName;
  String newImageName;

  public Sharpen(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length, commandLength);
    this.currentImageName = cmd[1];
    this.newImageName = cmd[2];
  }


  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.sharpen(this.currentImageName,this.newImageName);
  }

}
