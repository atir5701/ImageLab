package Controller.Commands;

import Model.Operations;

public class BrightnessComponent extends AbstractCommandExecuter {
  String currentImageName;
  String newImageName;
  String handler;

  public BrightnessComponent(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length,commandLength);
    this.currentImageName = cmd[1];
    this.newImageName = cmd[2];
    this.handler = cmd[0];
  }
  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    operations.getBrightnessComponent(this.currentImageName,this.newImageName,this.handler);
  }
}
