package Controller.Commands;

import Model.Operations;

public interface CommandExecuter {

  void validCommandLength(int length1,int length2) throws IllegalArgumentException;

  void imageCheck(Operations operations,String imageName) throws IllegalArgumentException;

  void execute(Operations operations);

}
