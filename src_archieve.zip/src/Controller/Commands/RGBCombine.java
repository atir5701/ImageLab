package Controller.Commands;

import Model.Operations;

public class RGBCombine extends AbstractCommandExecuter{
  String newImageName;
  String redImage;
  String greenImage;
  String blueImage;

  public RGBCombine(String[] cmd,int commandLength) {
    this.validCommandLength(cmd.length,commandLength);
    this.newImageName = cmd[1];
    this.redImage = cmd[2];
    this.greenImage = cmd[3];
    this.blueImage = cmd[4];
  }

  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.redImage);
    this.imageCheck(operations,this.greenImage);
    this.imageCheck(operations,this.blueImage);
    operations.combineRGB(this.redImage,this.greenImage,this.blueImage,this.newImageName);
  }
}
