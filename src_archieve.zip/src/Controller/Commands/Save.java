package Controller.Commands;

import java.awt.image.BufferedImage;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.imageio.ImageIO;

import Model.Operations;

public class Save extends AbstractCommandExecuter{
  private String filePath;
  private String currentImageName;
  private String extension;

  public Save(String[] cmd,int commandLength){
    this.validCommandLength(cmd.length,commandLength);
    this.filePath = cmd[1];
    this.extension = this.filePath.substring(this.filePath.lastIndexOf(".")+1);
    this.currentImageName = cmd[2];
  }

  @Override
  public void execute(Operations operations) {
    this.imageCheck(operations,this.currentImageName);
    switch (this.extension){
      case "png":
      case "jpeg":
        this.savePngJpeg(operations);
        break;
      case "ppm":
        this.savePPM(operations);
        break;
      default:
        throw new IllegalArgumentException("This extension is not Supported");
    }
  }

  private void savePngJpeg(Operations operations){
    int [][][] arr = operations.getImage(this.currentImageName);
    File file = new File(this.filePath);
    int width = arr[0].length;
    int height = arr.length;
    BufferedImage img = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
    try {
      for (int i = 0; i < arr.length; i++) {
        for (int j = 0; j < arr[i].length; j++) {
          int rgb = arr[i][j][0] << 16 | arr[i][j][1] << 8 |
                  arr[i][j][2];
          img.setRGB(j, i, rgb);
        }
      }
      ImageIO.write(img, extension, file);
    } catch (IOException e) {
      System.out.println("File Not Found");
    }

  }

  private void savePPM(Operations operations){
    int [][][] arr = operations.getImage(this.currentImageName);
    try {
      File output = new File(filePath);
      BufferedWriter bw = new BufferedWriter(new FileWriter(output));
      bw.write("P3\n");
      bw.write("#"+this.currentImageName +".PPM Image\n");
      bw.write(arr[0].length +" "+arr.length+"\n");
      bw.write("255\n");

      for(int i=0;i<arr.length;i++){
        for(int j=0;j<arr[i].length;j++){
          bw.write(arr[i][j][0]+" "+arr[i][j][1]+" "+arr[i][j][2]+" ");
        }
        bw.write("\n");
      }
      bw.close();
    }catch(IOException e){
      System.out.println("File Not Found");
    }
  }

}
